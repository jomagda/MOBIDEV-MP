package seattlesbest.angtaasapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Dalag, Magdaraog, Raymundo on 11/10/2017.
 */

public class EditFlashcardActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editflashcard);

    }
}
